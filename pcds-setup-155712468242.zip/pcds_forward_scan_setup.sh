#!/bin/sh

function Usage() {
    echo "Usage: $0  -f <FILE_NAME>"
    echo ""
    echo "where:"
    echo "     -f: Specify the text file with account details to be on-boarded"                
    echo ""
}

if [ $# -lt 1 ] ; then
    Usage
    exit 1
fi


echo " "
echo "-----------------------------------------------------------------------------------------------------------"
echo "--- Executing Simplified Forward Scan setup based on the options selected in 'Define Forward Scan Step' ---"
echo "-----------------------------------------------------------------------------------------------------------"
echo " "
while read -r line; do declare "$line"; done < config.txt
echo "AWS Account ID      :" $account_id
echo "AWS Region          :" $region;
echo "Cloud Trail Name    :" $cloud_trail_name;
echo "Cloud Trail Option  :" $cloud_trail_request_type;
echo "SNSTopic Name       :" $sns_topic_name;
echo "SNSTopic Option     :" $sns_topic_request_type;
echo "S3 Bucket Name      :" $s3_bucket_name;
echo "S3 Bucket Option    :" $s3_bucket_request_type;
echo "Common CT Bucket    :" $common_ct_bucket;
echo "SNS Endpoint        :" $sns_end_point;
echo "---------------------------------------------------------------------------------------------------------"
echo " "

# Input validation

[ -z "${account_id}" ] && echo "AWS Account ID is not set or empty. Please fix and rerun" && exit 1
[ -z "${region}" ] && echo "AWS Region is not set or empty. Please fix and rerun" && exit 1
[ -z "${cloud_trail_name}" ] && echo "Cloud Trail Name is not set or empty. Please fix and rerun" && exit 1
[ -z "${cloud_trail_request_type}" ] && echo "Cloud Trail Option is not set or empty. Please fix and rerunn" && exit 1
[ -z "${sns_topic_name}" ] && echo "SNSTopic Name is not set or empty. Please fix and rerun" && exit 1
[ -z "${sns_topic_request_type}" ] && echo "SNSTopic Option is not set or empty. Please fix and rerun" && exit 1
[ -z "${s3_bucket_name}" ] && echo "S3 Bucket Name is not set or empty. Please fix and rerun" && exit 1
[ -z "${s3_bucket_request_type}" ] && echo "S3 Bucket Option is not set or empty. Please fix and rerun" && exit 1
[ -z "${common_ct_bucket}" ] && echo "Common CT Bucket is not set or empty. Please fix and rerun" && exit 1
[ -z "${sns_end_point}" ] && echo "SNS Endpoint is not set or empty. Please fix and rerun" && exit 1


# Setting SNSTopicName
SNSTopicName=$sns_topic_name

if [[ "$common_ct_bucket" == "no" ]] || [[ "$common_ct_bucket" == "NO" ]] || [[ "$common_ct_bucket" == "No" ]] ; then
    if [[ "$s3_bucket_request_type" == "new" ]] || [[ "$s3_bucket_request_type" == "NEW" ]] || [[ "$s3_bucket_request_type" == "New" ]] ; then
        echo "                  [START] : Creating a new bucket to store CloudTrail Logs                              "
        echo "--------------------------------------------------------------------------------------------------------"
        echo " "
        if [[ "$region" == "us-east-1" ]]  ; then
            aws s3api create-bucket --bucket $s3_bucket_name
        else
            aws s3api create-bucket --bucket $s3_bucket_name --region $region --create-bucket-configuration LocationConstraint=$region
        fi

        cmd_status=$?
        [ $cmd_status -eq 0 ] && echo "Bucket Creation successful !" || { echo "Bucket Creation Failed with status code : $cmd_status" ; exit $cmd_status ; }

        echo " "
        echo "--------------------------------------------------------------------------------------------------------" 
        echo "Updating S3 Bucket Policy to store the CloudTrail Logs"

        cft_script="aws cloudformation create-stack --stack-name PCDS-CT-BucketPolicy --template-body file://update_bucket_policy.json --capabilities CAPABILITY_NAMED_IAM --parameters ParameterKey=S3Bucket,ParameterValue=\"$s3_bucket_name\" --region $region"
        echo "--------------------------------------------------------------------------------------------------------"
        eval "$cft_script"

        cft_status=$?
        [ $cft_status -eq 0 ] && echo "stack creation started Successfully !" || { echo "stack creation failed with above error and error code : $cft_status" ; exit $cft_status ; }

        cft_script="aws cloudformation wait stack-create-complete --stack-name PCDS-CT-BucketPolicy --region $region"
        echo " "
        echo "--------------------------------------------------------------------------------------------------------"
        echo "Wait until stack creation to complete"
        eval "$cft_script"
        cft_status=$?
        [ $cft_status -eq 0 ] && echo "stack creation successful !" || { echo "stack creation failed with error $cft_status" ; exit $cft_status ; }
        echo "                  [END] : Successful creation of new bucket to store CloudTrail Logs                    "
        echo "--------------------------------------------------------------------------------------------------------"
        echo " "
        # Sleep for 20 seconds for the bucket policy changes to reflect for future steps                    
        sleep 20
    fi 
    if [[ "$s3_bucket_request_type" == "unlinked" ]] || [[ "$s3_bucket_request_type" == "UNLINKED" ]] || [[ "$s3_bucket_request_type" == "Unlinked" ]] ; then

        echo "                  [START] : Updating the existing S3 bucket's policy to store CloudTrail Logs           "
        echo "--------------------------------------------------------------------------------------------------------"
        echo " "

        aws_cmd="aws s3api get-bucket-location --bucket $s3_bucket_name > _s3_location.json"
        eval "$aws_cmd"

        cmd_status=$?
        [ $cmd_status -eq 0 ] && echo "stack creation successful !" || { echo "stack creation failed with error $cmd_status" ; exit $cmd_status ; }

        s3_region=`jq -r .LocationConstraint _s3_location.json`

        if [[ "$s3_region" == "null" ]] ; then
            echo "Setting bucket region to default : us-east-1"    
            s3_region="us-east-1"
        fi

        echo "Bucket Location : "
        echo $s3_region

        cft_script="aws cloudformation create-stack --stack-name PCDS-CT-BucketPolicy --template-body file://update_bucket_policy.json --capabilities CAPABILITY_NAMED_IAM --parameters ParameterKey=S3Bucket,ParameterValue=\"$s3_bucket_name\" --region $s3_region"
        echo "--------------------------------------------------------------------------------------------------------"
        eval "$cft_script"

        cft_status=$?
        [ $cft_status -eq 0 ] && echo "stack creation started Successfully !" || { echo "stack creation failed with above error and error code : $cft_status" ; exit $cft_status ; }

        cft_script="aws cloudformation wait stack-create-complete --stack-name PCDS-CT-BucketPolicy --region $s3_region"
        echo "--------------------------------------------------------------------------------------------------------"
        echo "Wait until stack creation to complete"
        eval "$cft_script"
        cft_status=$?
        [ $cft_status -eq 0 ] && echo "stack creation successful !" || { echo "stack creation failed with error $cft_status" ; exit $cft_status ; }
        echo "         [END] : Successfully update the existing S3 bucket's policy to store CloudTrail Logs           "
        echo "--------------------------------------------------------------------------------------------------------"
        echo " "  
        # Sleep for 20 seconds for the bucket policy changes to reflect for future steps      
        sleep 20
    fi
elif [[ "$common_ct_bucket" == "yes" ]] || [[ "$common_ct_bucket" == "YES" ]] || [[ "$common_ct_bucket" == "Yes" ]] ; then 
    echo "--------------------------------------------------------------------------------------------------------"
    echo "Since S3 Bucket from Common Logging Account is specified, there will not be any policy update to this bucket"
    echo " "
    echo "Make sure you have configured the bucket permission as per following doc : "
    echo " "
    echo "https://docs.aws.amazon.com/awscloudtrail/latest/userguide/create-s3-bucket-policy-for-cloudtrail.html"
    echo "--------------------------------------------------------------------------------------------------------"
fi

if [[ "$sns_topic_request_type" == "new" ]] || [[ "$sns_topic_request_type" == "NEW" ]] || [[ "$sns_topic_request_type" == "New" ]] ; then
    #SNSTopicName="arn:aws:sns:$region:${account_id}:${sns_topic_name}"
    
    echo "      [START] : Creating SNSTopic with subscription to send object and bucket events notifications      "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "    
    echo $SNSTopicName

    cft_script="aws cloudformation create-stack --stack-name PCDS-SNSTopic --template-body file://create_sns_topic.json --capabilities CAPABILITY_NAMED_IAM --parameters ParameterKey=SNSTopicName,ParameterValue=\"$SNSTopicName\" ParameterKey=SNSEndpoint,ParameterValue=\"$sns_end_point\" --region $region"
    echo "--------------------------------------------------------------------------------------------------------"
    eval "$cft_script"

    cft_status=$?
    [ $cft_status -eq 0 ] && echo "stack creation started Successfully !" || { echo "stack creation failed with above error and error code : $cft_status" ; exit $cft_status ; }

    cft_script="aws cloudformation wait stack-create-complete --stack-name PCDS-SNSTopic --region $region"
    echo "--------------------------------------------------------------------------------------------------------"
    echo "Wait until stack creation to complete"
    eval "$cft_script"
    cft_status=$?
    [ $cft_status -eq 0 ] && echo "stack creation successful !" || { echo "stack creation failed with error $cft_status" ; exit $cft_status ; }
    echo "[END] : Successful creation of SNSTopic with subscription to send object and bucket events notifications"
    echo "--------------------------------------------------------------------------------------------------------"    

elif [[ "$sns_topic_request_type" == "linked" ]] || [[ "$sns_topic_request_type" == "LINKED" ]] || [[ "$sns_topic_request_type" == "Linked" ]] ; then
    echo " "
    echo "                  [START] : Updating existing SNSTopic with subscription URL                            "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "
    IFS=':' read -r -a arn_array <<< "$sns_topic_name"
    echo "${arn_array[3]}"    
    sns_region=${arn_array[3]}
    echo "$sns_region"

    aws_cmd_line="aws sns subscribe --topic-arn $sns_topic_name --protocol https --notification-endpoint $sns_end_point --region $sns_region"
    echo "$aws_cmd_line"
    eval "$aws_cmd_line"

    cmd_status=$?
    [ $cmd_status -eq 0 ] && echo "Updating existing SNSTopic with subscription URL successful !" || { echo "Updating existing SNSTopic with subscription URL failed with error $cmd_status" ; exit $cmd_status ; }

    echo "                  [END] : Successfully update the existing SNSTopic with subscription URL               "
    echo "--------------------------------------------------------------------------------------------------------"      
elif [[ "$sns_topic_request_type" == "unlinked" ]] || [[ "$sns_topic_request_type" == "UNLINKED" ]] || [[ "$sns_topic_request_type" == "Unlinked" ]] ; then    
    echo " "
    echo "                  [START] : Updating existing SNSTopic with subscription URL and Topic's Policy         "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "
    IFS=':' read -r -a arn_array <<< "$sns_topic_name"
    echo "${arn_array[3]}"    
    sns_region=${arn_array[3]}
    echo "$sns_region"

    echo "Updating SNSTopic with subscription URL"    
    aws_cmd_line="aws sns subscribe --topic-arn $sns_topic_name --protocol https --notification-endpoint $sns_end_point --region $sns_region"
    echo "$aws_cmd_line"
    eval "$aws_cmd_line"

    cmd_status=$?
    [ $cmd_status -eq 0 ] && echo "Updating SNSTopic with subscription URL is successful !" || { echo "Updating SNSTopic with subscription URL failed with error $cmd_status" ; exit $cmd_status ; }

    echo "Getting Existing Topic Attributes"
    rm -f _*.json
    aws_cmd_line="aws sns get-topic-attributes --topic-arn $sns_topic_name --region $sns_region > _topic_attributes.json"
    echo "$aws_cmd_line"
    eval "$aws_cmd_line"

    cmd_status=$?
    [ $cmd_status -eq 0 ] && echo "Getting Existing Topic Attributes is successful !" || { echo "Getting Existing Topic Attributes failed with error $cmd_status . Please make sure SNSTopic is given in ARN format" ; exit $cmd_status ; }

    # Parse the Poilcy and append "cloudtrail.amazonaws.com" service
    jq .Attributes.Policy _topic_attributes.json >> _temp_topic_policy.json
    jq -r . _temp_topic_policy.json | jq -r .Statement[1]="{\"Action\":\"SNS:Publish\",\"Effect\":\"Allow\",\"Principal\":{\"Service\":\"cloudtrail.amazonaws.com\"},\"Resource\":\"$sns_topic_name\",\"Sid\":\"AWSCloudTrailSNSPolicy20150319\"}" >> _with_policy_stmt.json
    jq -rc . _with_policy_stmt.json >> _raw_with_policy_stmt.json
    cat _raw_with_policy_stmt.json | sed 's/"/\\"/g' >> _raw_and_escaped_with_policy_stmt.json
    policy_content=`cat _raw_and_escaped_with_policy_stmt.json`

    echo "$policy_content"

    echo "Updating Topic's Policy "
    aws_cmd_line="aws sns set-topic-attributes --topic-arn $sns_topic_name --attribute-name "Policy" --attribute-value \"$policy_content\" --region $sns_region"
    echo "$aws_cmd_line"
    eval "$aws_cmd_line" 

    cmd_status=$?
    [ $cmd_status -eq 0 ] && echo "Updating Topic's Policy is successful !" || { echo "Updating Topic's Policy failed with error $cmd_status" ; exit $cmd_status ; }

    echo " "
    echo "       [END] : Successfully update the existing SNSTopic with subscription URL and Topic's Policy       "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "    
fi


if [[ "$cloud_trail_request_type" == "new" ]] || [[ "$cloud_trail_request_type" == "NEW" ]] || [[ "$cloud_trail_request_type" == "New" ]] ; then

    echo " "
    echo "                          [START] : Creating a new CloudTrail                                           "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "

    #SNSTopicName="arn:aws:sns:$region:${account_id}:${sns_topic_name}"
    echo $SNSTopicName
    echo " "


    if [[ "$common_ct_bucket" == "no" ]] || [[ "$common_ct_bucket" == "NO" ]] || [[ "$common_ct_bucket" == "No" ]] ; then 
        echo "Creating CloudTrail with new S3 Bucket for storing logs"
        cft_script="aws cloudformation create-stack --stack-name PCDS-CT --template-body file://common_ct_bucket.json --capabilities CAPABILITY_NAMED_IAM --parameters ParameterKey=SNSTopicName,ParameterValue=\"$SNSTopicName\" ParameterKey=S3Bucket,ParameterValue=\"$s3_bucket_name\" ParameterKey=CTTrailName,ParameterValue=\"$cloud_trail_name\" --region $region"
        echo "--------------------------------------------------------------------------------------------------------"
        eval "$cft_script"
    fi

    if [[ "$common_ct_bucket" == "yes" ]] || [[ "$common_ct_bucket" == "YES" ]] || [[ "$common_ct_bucket" == "Yes" ]] ; then 
        echo "Updating CloudTrail with Management and Data events"
        cft_script="aws cloudformation create-stack --stack-name PCDS-CT --template-body file://common_ct_bucket.json --capabilities CAPABILITY_NAMED_IAM --parameters ParameterKey=SNSTopicName,ParameterValue=\"$SNSTopicName\" ParameterKey=S3Bucket,ParameterValue=\"$s3_bucket_name\" ParameterKey=CTTrailName,ParameterValue=\"$cloud_trail_name\" --region $region"
        echo "--------------------------------------------------------------------------------------------------------"
        eval "$cft_script"
    fi

    cft_status=$?
    [ $cft_status -eq 0 ] && echo "stack creation started Successfully !" || { echo "stack creation failed with above error and error code : $cft_status" ; exit $cft_status ; }

    cft_script="aws cloudformation wait stack-create-complete --stack-name PCDS-CT --region $region"
    echo "--------------------------------------------------------------------------------------------------------"
    echo "Wait until stack creation to complete"
    eval "$cft_script"
    cft_status=$?
    [ $cft_status -eq 0 ] && echo "stack creation successful !" || { echo "stack creation failed with error $cft_status" ; exit $cft_status ; }
    echo " "
    echo "                          [END] : Successfully created the CloudTrail                                   "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "  
elif [[ "$cloud_trail_request_type" == "update" ]] || [[ "$cloud_trail_request_type" == "UPDATE" ]] || [[ "$cloud_trail_request_type" == "Update" ]] ; then
    echo " "
    echo "                          [START] : Updating existing CloudTrail with SNSTopic                          "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "
    if [[ "$sns_topic_request_type" == "new" ]] || [[ "$sns_topic_request_type" == "NEW" ]] || [[ "$sns_topic_request_type" == "New" ]] ; then
        # echo "--------------------------------------------------------------------------------------------------------" 
        # echo "Updating CloudTrail with SNSTopic"
        aws_cmd_line="aws cloudtrail update-trail --name $cloud_trail_name --sns-topic-name $sns_topic_name --region $region"
        echo "$aws_cmd_line"
        eval "$aws_cmd_line"
    elif [[ "$sns_topic_request_type" == "unlinked" ]] || [[ "$sns_topic_request_type" == "UNLINKED" ]] || [[ "$sns_topic_request_type" == "Unlinked" ]] ; then
        # echo "Updating CloudTrail with SNSTopic"
        aws_cmd_line="aws cloudtrail update-trail --name $cloud_trail_name --sns-topic-name $sns_topic_name"
        echo "$aws_cmd_line"
        eval "$aws_cmd_line" 
    fi

    cmd_status=$?
    [ $cmd_status -eq 0 ] && echo "Updating CloudTrail with SNSTopic is successful !" || { echo "Updating CloudTrail with SNSTopic failed with error $cmd_status" ; exit $cmd_status ; }

    echo " "
    echo "                      [START] : Enabling Management and Data Events in the existing CloudTrail          "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "
    echo "Updating Management and Data Events"
    events_settings='[{"IncludeManagementEvents":true,"ReadWriteType":"WriteOnly"},{"DataResources":[{"Type":"AWS::S3::Object","Values":["arn:aws:s3:::"]}],"ReadWriteType":"WriteOnly"}]'
    aws_cmd_line="aws cloudtrail put-event-selectors --trail-name $cloud_trail_name --event-selectors '$events_settings' --region $region"
    echo "$aws_cmd_line"
    eval "$aws_cmd_line"

    cmd_status=$?
    [ $cmd_status -eq 0 ] && echo "Updating Management and Data Events successful !" || { echo "Updating Management and Data Events failed with error $cmd_status" ; exit $cmd_status ; }

    echo " "
    echo "    [END] : Successsfully completed Enabling Management and Data Events in the existing CloudTrail      "
    echo "--------------------------------------------------------------------------------------------------------"
    echo " "
fi
